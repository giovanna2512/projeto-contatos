
package br.senac.tads.dsw.projetocontatos;

import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author giovanna.palmeida1
 */

@RestController 
@RequestMapping("/contatos")
public class ContatoRestController {
    
    @GetMapping("/lista")
    public List<Contatos> listar(){
        List<Contatos> lista = new ArrayList<>();
        lista.add(new Contatos("Giovanna Prates","(11) 92233-5566", "giovannaprates@email.com.br",1,LocalDate.parse ("2000-10-29")));
        return lista;
    }
}
