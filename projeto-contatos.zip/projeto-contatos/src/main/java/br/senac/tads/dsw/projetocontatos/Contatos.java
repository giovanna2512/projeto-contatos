
package br.senac.tads.dsw.projetocontatos;

import java.time.LocalDate;
/**
 *
 * @author giovanna.palmeida1
 */
public class Contatos {

    private String nome;

    private String telefone;

    private String email;

    private Integer id;

    private LocalDate dataNascimento;

    
    public Contatos() {
    }

    public Contatos(String nome, String telefone, String email, int id, LocalDate dataNascimento) {
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.id = id;
        this.dataNascimento = dataNascimento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    
    

}
